//
//  NativeAdView.h
//  ConsoliAd
//
//  Created by rehmanaslam on 06/12/2018.
//  Copyright © 2018 FazalElahi. All rights reserved.
//
