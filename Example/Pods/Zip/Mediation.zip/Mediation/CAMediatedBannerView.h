//
//  CAmediatedBannerView.h
//  ConsoliMediation
//
//  Created by saira on 24/10/2019.
//  Copyright © 2019 ConsoliAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import "CAMediationConstants.h"

@class AdNetwork;
@protocol CAMediatedBannerAdViewDelegate;

@interface CAMediatedBannerView : UIView

@property (nonatomic) AdNetwork *adNetwork;
@property (nonatomic , readonly) CGSize customSize;
@property (nonatomic, weak) id<CAMediatedBannerAdViewDelegate> delegate;
@property (nonatomic) PlaceholderName bannerPlaceholderName;
@property (nonatomic) BannerState bannerState;
@property (nonatomic) float bannerLoadTime;

- (void)setCustomBannerSize:(CGSize)size;
- (void)destroyBanner;
- (BOOL)canLoadBanner: (PlaceholderName)placeholderName;
- (void)setAdNetwork:(AdNetwork*)adNetwork placHolderName:(PlaceholderName)placeholderName;
- (AdNetwork*)getAdnetwork;
- (void)setBannerState:(BannerState)bannerState;
- (BannerState)getBannerState;
- (void)onBannerAdFailToShowEvent;
@end

@protocol CAMediatedBannerAdViewDelegate <NSObject>

@optional

- (void)onBannerAdLoaded:(CAMediatedBannerView*)bannerView;

- (void)onBannerAdLoadFailed:(CAMediatedBannerView*)bannerView;

- (void)onBannerAdClicked;

- (void)onBannerAdRefreshEvent;

@end

